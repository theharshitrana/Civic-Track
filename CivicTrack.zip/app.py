import os
import re
from flask import Flask, jsonify, request, render_template
from flask_socketio import SocketIO, emit
from geoalchemy2 import Geography
from geoalchemy2.functions import ST_DWithin, ST_MakePoint
from flask_sqlalchemy import SQLAlchemy
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv(
    'DATABASE_URL',
    'postgresql://civictrack_user:securepassword@localhost:5432/civictrack'
)
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'your-secret-key-here')

db = SQLAlchemy(app)
socketio = SocketIO(app)

class Issue(db.Model):
    __tablename__ = 'issues'
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(50), nullable=False)
    location = db.Column(Geography('POINT', srid=4326))
    status = db.Column(db.String(20), default='reported')
    created_at = db.Column(db.DateTime, server_default=db.func.now())
    updated_at = db.Column(db.DateTime, server_default=db.func.now(), onupdate=db.func.now())

    def __repr__(self):
        return f'<Issue {self.id}: {self.title}>'

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/api/issues', methods=['GET'])
def get_issues():
    try:
        lat = request.args.get('lat', type=float)
        lng = request.args.get('lng', type=float)
        radius = request.args.get('radius', default=5, type=float)
        status = request.args.get('status')
        category = request.args.get('category')

        if lat is None or lng is None:
            return jsonify({'error': 'Latitude and longitude are required'}), 400

        point = ST_MakePoint(lng, lat)
        query = Issue.query.filter(ST_DWithin(Issue.location, point, radius * 1000))

        if status:
            query = query.filter(Issue.status == status)
        if category:
            query = query.filter(Issue.category == category)

        issues = query.all()

        issues_data = [{
            'id': issue.id,
            'title': issue.title,
            'description': issue.description,
            'category': issue.category,
            'latitude': db.session.scalar(issue.location.ST_Y()),
            'longitude': db.session.scalar(issue.location.ST_X()),
            'status': issue.status,
            'created_at': issue.created_at.isoformat(),
            'updated_at': issue.updated_at.isoformat()
        } for issue in issues]

        return jsonify(issues_data)

    except Exception as e:
        app.logger.error(f"Error fetching issues: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@app.route('/api/suggest', methods=['POST'])
def get_suggestions():
    try:
        data = request.get_json()
        field = data.get('field')
        text = data.get('text', '')
        
        suggestions = []
        if field == 'title':
            suggestions = [
                "Pothole on Main Street",
                "Broken streetlight on Oak Avenue",
                "Garbage accumulation in Central Park",
                "Water leak at 5th and Elm",
                "Fallen tree blocking road on Pine Street"
            ]
        elif field == 'description':
            suggestions = [
                "Large pothole causing traffic issues",
                "Street light not working for 3 days",
                "Garbage bins overflowing with trash",
                "Water leaking from broken pipe",
                "Tree branch blocking entire road"
            ]
        
        # Filter based on input
        filtered = [s for s in suggestions if text.lower() in s.lower()]
        return jsonify({'suggestions': filtered[:3]})
    
    except Exception as e:
        app.logger.error(f"Suggestion error: {str(e)}")
        return jsonify({'suggestions': []})

@app.route('/api/issues', methods=['POST'])
def create_issue():
    try:
        data = request.get_json()

        # Clean and validate input
        title = clean_input(data.get('title', ''))
        description = clean_input(data.get('description', ''))
        category = data.get('category', '')

        # Validate fields
        if not title or len(title) < 5:
            return jsonify({'error': 'Title must be at least 5 characters'}), 400
        
        if not description or len(description) < 10:
            return jsonify({'error': 'Description must be at least 10 characters'}), 400
            
        if not category:
            return jsonify({'error': 'Category is required'}), 400

        # Create new issue
        new_issue = Issue(
            title=title,
            description=description,
            category=category,
            location=ST_MakePoint(
                float(data.get('longitude', 0)),
                float(data.get('latitude', 0))
            ),
            status='reported'
        )

        db.session.add(new_issue)
        db.session.commit()

        # Emit to all clients
        socketio.emit('new_issue', {
            'id': new_issue.id,
            'title': new_issue.title,
            'latitude': db.session.scalar(new_issue.location.ST_Y()),
            'longitude': db.session.scalar(new_issue.location.ST_X()),
            'status': new_issue.status,
            'category': new_issue.category
        })

        return jsonify({
            'id': new_issue.id,
            'message': 'Issue reported successfully'
        }), 201

    except Exception as e:
        db.session.rollback()
        app.logger.error(f"Error creating issue: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

def clean_input(text):
    """Clean and format user input"""
    # Remove extra spaces
    text = re.sub(r'\s+', ' ', text).strip()
    # Capitalize first letter
    if text:
        text = text[0].upper() + text[1:]
    return text

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        if not Issue.query.first():
            sample_issue = Issue(
                title='Sample Road Issue',
                description='Large pothole causing traffic problems',
                category='roads',
                location=ST_MakePoint(77.5946, 12.9716),
                status='reported'
            )
            db.session.add(sample_issue)
            db.session.commit()
    
    socketio.run(app, host='0.0.0.0', port=5000, debug=True)