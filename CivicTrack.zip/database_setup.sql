-- Enable PostGIS
CREATE EXTENSION IF NOT EXISTS postgis;

-- Create issues table
CREATE TABLE IF NOT EXISTS issues (
    id SERIAL PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    description TEXT NOT NULL,
    category VARCHAR(50) NOT NULL,
    location GEOGRAPHY(POINT, 4326) NOT NULL,
    status VARCHAR(20) DEFAULT 'reported',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create spatial index if not exists
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_indexes 
        WHERE tablename = 'issues' AND indexname = 'idx_issues_location'
    ) THEN
        CREATE INDEX idx_issues_location ON issues USING GIST(location);
    END IF;
END $$;

-- Add status constraint if not exists
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'status_check'
    ) THEN
        ALTER TABLE issues 
        ADD CONSTRAINT status_check 
        CHECK (status IN ('reported', 'in_progress', 'resolved'));
    END IF;
END $$;