document.addEventListener('DOMContentLoaded', () => {
    // Initialize map
    const map = L.map('map').setView([12.9716, 77.5946], 13);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
    }).addTo(map);

    // Custom marker icons
    const markerIcons = {
        reported: L.icon({
            iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-red.png',
            iconSize: [32, 32],
            iconAnchor: [16, 32]
        }),
        in_progress: L.icon({
            iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-yellow.png',
            iconSize: [32, 32],
            iconAnchor: [16, 32]
        }),
        resolved: L.icon({
            iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-green.png',
            iconSize: [32, 32],
            iconAnchor: [16, 32]
        })
    };

    // DOM Elements
    const issueForm = document.getElementById('issueForm');
    const titleInput = document.getElementById('title');
    const descriptionInput = document.getElementById('description');
    const categorySelect = document.getElementById('category');
    const submitButton = document.getElementById('submitBtn');
    const messageDiv = document.getElementById('message');
    const statusFilter = document.getElementById('statusFilter');
    const categoryFilter = document.getElementById('categoryFilter');
    const radiusFilter = document.getElementById('radiusFilter');
    const applyFiltersBtn = document.getElementById('applyFilters');
    const clearFormBtn = document.getElementById('clearForm');
    const charCounter = document.getElementById('charCounter');
    const titleSuggestions = document.getElementById('title-suggestions');
    const descSuggestions = document.getElementById('description-suggestions');

    let currentLocation = { lat: 12.9716, lng: 77.5946 };
    let markers = [];
    let typingTimer;
    const doneTypingInterval = 500;

    // Initialize WebSocket connection
    const socket = io();

    // Listen for new issues
    socket.on('new_issue', (issue) => {
        addMarkerToMap(issue);
        showMessage(`New issue reported: ${issue.title}`, 'success');
    });

    // Add marker to map
    function addMarkerToMap(issue) {
        const marker = L.marker([issue.latitude, issue.longitude], { 
            icon: markerIcons[issue.status] || markerIcons.reported 
        }).bindPopup(`
            <div class="popup-content">
                <h3>${issue.title}</h3>
                <p><strong>Status:</strong> <span class="status-${issue.status}">${issue.status.replace('_', ' ')}</span></p>
                <p><strong>Category:</strong> ${issue.category}</p>
                <p>${issue.description}</p>
                <small>Reported: ${new Date(issue.created_at).toLocaleString()}</small>
            </div>
        `).addTo(map);
        
        markers.push(marker);
    }

    // Get user location
    function getUserLocation() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                position => {
                    currentLocation = {
                        lat: position.coords.latitude,
                        lng: position.coords.longitude
                    };
                    map.setView([currentLocation.lat, currentLocation.lng], 14);
                    loadIssues();
                },
                error => {
                    console.error('Geolocation error:', error);
                    showMessage('Could not get your location. Using default location.', 'error');
                    loadIssues();
                }
            );
        } else {
            showMessage('Geolocation is not supported by your browser', 'error');
            loadIssues();
        }
    }

    // Load issues from API
    async function loadIssues() {
        try {
            clearMarkers();
            
            const params = new URLSearchParams({
                lat: currentLocation.lat,
                lng: currentLocation.lng,
                radius: radiusFilter.value,
                status: statusFilter.value,
                category: categoryFilter.value
            });

            const response = await fetch(`/api/issues?${params}`);
            
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || 'Failed to load issues');
            }

            const issues = await response.json();
            
            issues.forEach(issue => {
                addMarkerToMap(issue);
            });
        } catch (error) {
            showMessage(`Error: ${error.message}`, 'error');
        }
    }

    // Clear markers
    function clearMarkers() {
        markers.forEach(marker => map.removeLayer(marker));
        markers = [];
    }

    // Show message
    function showMessage(text, type = 'error') {
        messageDiv.textContent = text;
        messageDiv.className = `message ${type}`;
        messageDiv.style.display = 'block';
        
        setTimeout(() => {
            messageDiv.style.display = 'none';
        }, 5000);
    }

    // Form submission
    issueForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        // Basic validation
        if (!titleInput.value.trim()) {
            showMessage('Title is required', 'error');
            titleInput.focus();
            return;
        }
        
        if (!descriptionInput.value.trim()) {
            showMessage('Description is required', 'error');
            descriptionInput.focus();
            return;
        }
        
        if (!categorySelect.value) {
            showMessage('Please select a category', 'error');
            categorySelect.focus();
            return;
        }

        try {
            submitButton.disabled = true;
            submitButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Submitting...';
            
            // Submit form
            const response = await fetch('/api/issues', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    title: titleInput.value,
                    description: descriptionInput.value,
                    category: categorySelect.value,
                    latitude: currentLocation.lat,
                    longitude: currentLocation.lng
                })
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.error || 'Failed to report issue');
            }

            // Reset form
            issueForm.reset();
            charCounter.textContent = '0/200 characters';
            showMessage('Issue reported successfully! Officials have been notified.', 'success');
            
        } catch (error) {
            showMessage(`Error: ${error.message}`, 'error');
        } finally {
            submitButton.disabled = false;
            submitButton.innerHTML = '<i class="fas fa-paper-plane"></i> Submit Report';
        }
    });

    // Clear form
    clearFormBtn.addEventListener('click', () => {
        issueForm.reset();
        charCounter.textContent = '0/200 characters';
        titleSuggestions.style.display = 'none';
        descSuggestions.style.display = 'none';
    });

    // Apply filters
    applyFiltersBtn.addEventListener('click', loadIssues);

    // Character counter for description
    descriptionInput.addEventListener('input', function() {
        const charCount = this.value.length;
        charCounter.textContent = `${charCount}/200 characters`;
        
        if (charCount > 190) {
            charCounter.style.color = '#e74c3c';
        } else if (charCount > 150) {
            charCounter.style.color = '#f39c12';
        } else {
            charCounter.style.color = '#7f8c8d';
        }
    });

    // Auto-suggestions
    titleInput.addEventListener('input', function() {
        clearTimeout(typingTimer);
        if (this.value.length > 2) {
            typingTimer = setTimeout(() => {
                fetchSuggestions('title', this.value);
            }, doneTypingInterval);
        } else {
            titleSuggestions.style.display = 'none';
        }
    });

    descriptionInput.addEventListener('input', function() {
        clearTimeout(typingTimer);
        if (this.value.length > 5) {
            typingTimer = setTimeout(() => {
                fetchSuggestions('description', this.value);
            }, doneTypingInterval);
        } else {
            descSuggestions.style.display = 'none';
        }
    });

    // Get suggestions from server
    async function fetchSuggestions(field, text) {
        try {
            const response = await fetch('/api/suggest', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ field, text })
            });
            
            const data = await response.json();
            showSuggestions(field, data.suggestions);
        } catch (error) {
            console.error('Suggestion error:', error);
        }
    }

    // Display suggestions
    function showSuggestions(field, suggestions) {
        const container = field === 'title' ? titleSuggestions : descSuggestions;
        container.innerHTML = '';
        
        if (suggestions.length === 0) {
            container.style.display = 'none';
            return;
        }
        
        suggestions.forEach(suggestion => {
            const div = document.createElement('div');
            div.className = 'suggestion-item';
            div.textContent = suggestion;
            div.addEventListener('click', () => {
                if (field === 'title') {
                    titleInput.value = suggestion;
                } else {
                    descriptionInput.value = suggestion;
                }
                container.style.display = 'none';
            });
            container.appendChild(div);
        });
        
        container.style.display = 'block';
    }

    // Auto-format input
    titleInput.addEventListener('blur', function() {
        this.value = this.value
            .replace(/\s+/g, ' ')
            .trim()
            .replace(/^[a-z]/, (match) => match.toUpperCase());
    });

    // Initialize
    getUserLocation();
});